-- =====================================================================
-- Bright Solutions website: feedback section setup
-- Run this ONCE in Supabase: open your project > SQL Editor > New query,
-- paste everything below, then press Run.
-- Safe to run again if you need to.
-- =====================================================================

-- 1. The table that stores feedback ------------------------------------
create table if not exists public.feedback (
  id         bigint generated always as identity primary key,
  created_at timestamptz not null default now(),            -- date and time are set by the server, visitors cannot fake them
  name       text     not null check (char_length(name)     between 1  and 60),
  location   text     not null check (char_length(location) between 1  and 60),
  rating     smallint not null check (rating between 1 and 5),
  service    text              check (service is null or char_length(service) <= 40),
  message    text     not null check (char_length(message)  between 10 and 600),
  photos     text[]   not null default '{}' check (coalesce(array_length(photos, 1), 0) <= 3),
  reply      text              check (reply is null or char_length(reply) <= 600),   -- your reply, shown under the feedback
  hidden     boolean  not null default false                                          -- tick this to unpublish a post
);

alter table public.feedback enable row level security;

-- 2. Rules: visitors can read visible posts and add new ones. Nothing else.
drop policy if exists "visitors read visible feedback" on public.feedback;
create policy "visitors read visible feedback"
  on public.feedback for select to anon, authenticated
  using (hidden = false);

drop policy if exists "visitors post feedback" on public.feedback;
create policy "visitors post feedback"
  on public.feedback for insert to anon, authenticated
  with check (hidden = false and reply is null);

-- Visitors may only fill these columns. Time, reply and hidden stay under your control.
revoke all on public.feedback from anon, authenticated;
grant select on public.feedback to anon, authenticated;
grant insert (name, location, rating, service, message, photos) on public.feedback to anon, authenticated;
-- No update or delete is granted to visitors: only you, signed in to the Supabase dashboard, can edit, hide, reply to or delete posts.

-- 3. Photo storage ---------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('feedback-photos', 'feedback-photos', true, 3145728, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
  set public = true,
      file_size_limit = 3145728,
      allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp'];

drop policy if exists "visitors upload feedback photos" on storage.objects;
create policy "visitors upload feedback photos"
  on storage.objects for insert to anon, authenticated
  with check (bucket_id = 'feedback-photos');
-- Visitors can upload photos (max 3 MB each, images only) but cannot list, replace or delete any.

-- 4. Make the new table available straight away -------------------------------
notify pgrst, 'reload schema';
