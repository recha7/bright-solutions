-- =====================================================================
-- Bright Solutions website: library request tracker (Template 2)
-- Run ONCE in Supabase: SQL Editor > New query > paste all > Run.
-- This does not touch your feedback table. Safe to run again.
-- =====================================================================

-- 1. Every book request is logged here -----------------------------------
create table if not exists public.book_requests (
  id         bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  title      text not null check (char_length(title) between 1 and 200),
  author     text          check (author is null or char_length(author) <= 200),
  format     text          check (format is null or char_length(format) <= 40),
  kind       text          check (kind in ('listed', 'not-listed', 'online'))
);

alter table public.book_requests enable row level security;

drop policy if exists "visitors log book requests" on public.book_requests;
create policy "visitors log book requests"
  on public.book_requests for insert to anon, authenticated
  with check (true);

-- Visitors can only add a request. They cannot read, change or delete any.
revoke all on public.book_requests from anon, authenticated;
grant insert (title, author, format, kind) on public.book_requests to anon, authenticated;

-- 2. Demand list: which books are asked for most --------------------------
-- Open Table Editor > book_demand (or run: select * from public.book_demand;)
create or replace view public.book_demand as
  select title,
         author,
         count(*)                                             as requests,
         count(*) filter (where format ilike 'soft%')         as soft_copy,
         count(*) filter (where format ilike 'phys%')         as physical,
         count(*) filter (where kind = 'not-listed')          as not_on_list,
         max(created_at)                                      as last_requested
  from public.book_requests
  group by title, author
  order by requests desc, last_requested desc;

revoke all on public.book_demand from anon, authenticated;

notify pgrst, 'reload schema';
