-- =====================================================================
-- Bright Solutions website: owner-only admin (Template 2)
-- Run AFTER supabase-setup.sql and supabase-library.sql.
-- STEP 1: change YOUR_EMAIL_HERE@example.com below to your own email.
-- STEP 2: SQL Editor > New query > paste all > Run. Safe to run again.
-- =====================================================================

-- 0. Only this email counts as the owner --------------------------------
create or replace function public.is_owner() returns boolean
language sql stable as $$
  select lower(coalesce(auth.jwt() ->> 'email', '')) = lower('YOUR_EMAIL_HERE@example.com')
$$;

-- 1. Feedback: the owner can see everything, hide, reply and delete ----------
drop policy if exists "owner reads all feedback" on public.feedback;
create policy "owner reads all feedback" on public.feedback for select to authenticated using (public.is_owner());
drop policy if exists "owner edits feedback" on public.feedback;
create policy "owner edits feedback" on public.feedback for update to authenticated using (public.is_owner()) with check (public.is_owner());
drop policy if exists "owner deletes feedback" on public.feedback;
create policy "owner deletes feedback" on public.feedback for delete to authenticated using (public.is_owner());
grant update (hidden, reply) on public.feedback to authenticated;
grant delete on public.feedback to authenticated;

-- 2. Book requests: the owner can read them -----------------------------------
alter table public.book_requests drop constraint if exists book_requests_kind_check;
alter table public.book_requests add constraint book_requests_kind_check check (kind in ('listed', 'not-listed', 'online'));
drop policy if exists "owner reads book requests" on public.book_requests;
create policy "owner reads book requests" on public.book_requests for select to authenticated using (public.is_owner());
drop policy if exists "owner deletes book requests" on public.book_requests;
create policy "owner deletes book requests" on public.book_requests for delete to authenticated using (public.is_owner());
grant select, delete on public.book_requests to authenticated;
alter view public.book_demand set (security_invoker = true);
grant select on public.book_demand to authenticated;

-- 3. Book status (Available / Reserved) shown on the website ----------------
create table if not exists public.book_status (
  title      text primary key check (char_length(title) <= 200),
  status     text not null check (status in ('Available', 'Reserved')),
  updated_at timestamptz not null default now()
);
alter table public.book_status enable row level security;
drop policy if exists "everyone reads book status" on public.book_status;
create policy "everyone reads book status" on public.book_status for select to anon, authenticated using (true);
drop policy if exists "owner writes book status" on public.book_status;
create policy "owner writes book status" on public.book_status for all to authenticated using (public.is_owner()) with check (public.is_owner());
revoke all on public.book_status from anon, authenticated;
grant select on public.book_status to anon, authenticated;
grant insert, update, delete on public.book_status to authenticated;

notify pgrst, 'reload schema';
